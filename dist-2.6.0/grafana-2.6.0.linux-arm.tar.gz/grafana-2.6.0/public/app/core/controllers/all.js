/*! grafana - v2.6.0 - 2016-03-14
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./grafana_ctrl","./search_ctrl","./inspect_ctrl","./json_editor_ctrl","./login_ctrl","./invited_ctrl","./signup_ctrl","./reset_password_ctrl","./sidemenu_ctrl","./error_ctrl"],function(){});