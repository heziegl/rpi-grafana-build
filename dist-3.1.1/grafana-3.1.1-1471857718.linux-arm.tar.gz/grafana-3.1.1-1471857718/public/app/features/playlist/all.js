/*! grafana - v3.1.1-1471857718 - 2016-08-22
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./playlists_ctrl","./playlist_search","./playlist_srv","./playlist_edit_ctrl","./playlist_routes"],function(){});