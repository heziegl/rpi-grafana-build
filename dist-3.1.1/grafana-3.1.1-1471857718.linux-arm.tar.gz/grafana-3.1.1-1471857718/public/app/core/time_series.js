/*! grafana - v3.1.1-1471857718 - 2016-08-22
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./time_series2"],function(a){"use strict";return a["default"]});