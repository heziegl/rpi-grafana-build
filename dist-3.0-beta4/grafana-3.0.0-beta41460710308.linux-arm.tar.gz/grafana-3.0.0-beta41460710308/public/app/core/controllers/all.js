/*! grafana - v3.0.0-beta41460710308 - 2016-04-15
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./inspect_ctrl","./json_editor_ctrl","./login_ctrl","./invited_ctrl","./signup_ctrl","./reset_password_ctrl","./error_ctrl"],function(){});