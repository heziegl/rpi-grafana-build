/*! grafana - v3.0.0-beta41460710308 - 2016-04-15
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["app/core/settings"],function(a){"use strict";var b=window.grafanaBootData||{settings:{}},c=b.settings;return c.bootData=b,new a(c)});