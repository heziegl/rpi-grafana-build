/*! grafana - v3.0.0-beta41460710308 - 2016-04-15
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["./snapshot_ctrl"],function(a){return{setters:[function(a){}],execute:function(){}}});