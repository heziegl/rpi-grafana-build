declare var ElasticDatasource: any;
export {ElasticDatasource};

