/*! grafana - v3.0.0-beta61462053045 - 2016-04-30
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["lodash"],function(a){"use strict";return function(b){var c={datasources:{},window_title_prefix:"Grafana - ",panels:{},new_panel_title:"Panel Title",playlist_timespan:"1m",unsaved_changes_warning:!0,appSubUrl:""};return a.extend({},c,b)}});