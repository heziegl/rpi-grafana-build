/*! grafana - v3.0.0-beta61462053045 - 2016-04-30
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./time_series2"],function(a){"use strict";return a["default"]});