/*! grafana - v3.0.1- - 2016-05-13
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./org_users_ctrl","./profile_ctrl","./org_users_ctrl","./select_org_ctrl","./change_password_ctrl","./newOrgCtrl","./userInviteCtrl","./orgApiKeysCtrl","./orgDetailsCtrl","./prefs_control"],function(){});