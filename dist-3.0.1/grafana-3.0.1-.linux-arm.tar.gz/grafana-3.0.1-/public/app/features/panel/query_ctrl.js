/*! grafana - v3.0.1- - 2016-05-13
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register([],function(a){var b;return{setters:[],execute:function(){b=function(){function a(a,b){this.$scope=a,this.$injector=b,this.panel=this.panelCtrl.panel}return a.prototype.refresh=function(){this.panelCtrl.refresh()},a}(),a("QueryCtrl",b)}}});