/// <reference path="../../../public/app/headers/common.d.ts" />
declare var _default: any;
export default _default;
