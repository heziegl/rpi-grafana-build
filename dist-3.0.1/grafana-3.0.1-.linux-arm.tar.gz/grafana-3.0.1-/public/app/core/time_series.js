/*! grafana - v3.0.1- - 2016-05-13
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./time_series2"],function(a){"use strict";return a["default"]});