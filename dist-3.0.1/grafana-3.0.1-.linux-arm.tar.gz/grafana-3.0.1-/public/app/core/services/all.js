/*! grafana - v3.0.1- - 2016-05-13
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./alert_srv","./util_srv","./datasource_srv","./context_srv","./timer","./keyboard_manager","./analytics","./popover_srv","./segment_srv","./backend_srv","./dynamic_directive_srv"],function(){});