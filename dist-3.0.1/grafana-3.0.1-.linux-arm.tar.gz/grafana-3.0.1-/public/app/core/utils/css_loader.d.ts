/// <reference path="../../../../public/app/headers/common.d.ts" />
export declare function fetch(load: any): any;
