/*! grafana - v3.0.0-beta51460734510 - 2016-04-15
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

System.register(["lodash"],function(a){var b,c;return{setters:[function(a){b=a}],execute:function(){c=function(){function a(){}return a.prototype.parse=function(a,c){if(!c||0===c.results.length)return[];var d=c.results[0];if(!d.series)return[];var e=d.series[0];return b["default"].map(e.values,function(c){return b["default"].isArray(c)?a.toLowerCase().indexOf("show tag values")>=0?{text:c[1]||c[0]}:{text:c[0]}:{text:c}})},a}(),a("default",c)}}});