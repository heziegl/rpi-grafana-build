/*! grafana - v3.0.0-beta51460734510 - 2016-04-15
 * Copyright (c) 2016 Torkel Ödegaard; Licensed Apache-2.0 */

define(["./dashboardCtrl","./dashboardLoaderSrv","./dashnav/dashnav","./submenu/submenu","./saveDashboardAsCtrl","./rowCtrl","./shareModalCtrl","./shareSnapshotCtrl","./dashboardSrv","./keybindings","./viewStateSrv","./timeSrv","./unsavedChangesSrv","./timepicker/timepicker","./graphiteImportCtrl","./dynamicDashboardSrv","./importCtrl","./impression_store"],function(){});